const natural = require('natural');

class PhishingDetector {
  constructor() {
    this.classifier = new natural.BayesClassifier();
    this.trained = false;
  }

  train(trainingData) {
    trainingData.forEach(({ url, isPhishing }) => {
      const features = this._convertFeaturesToText(url);
      this.classifier.addDocument(features, isPhishing ? 'phishing' : 'legitimate');
    });
    
    this.classifier.train();
    this.trained = true;
  }

  predict(url) {
    if (!this.trained) {
      throw new Error('Model needs to be trained first');
    }
    
    const features = this._convertFeaturesToText(url);
    const classification = this.classifier.classify(features);
    return {
      isPhishing: classification === 'phishing',
      confidence: this.classifier.getClassifications(features)[0].value
    };
  }

  _convertFeaturesToText(url) {
    const { extractFeatures } = require('./features');
    const features = extractFeatures(url);
    
    // Convert numerical features to text representation
    return Object.entries(features)
      .map(([key, value]) => {
        if (typeof value === 'boolean') {
          return value ? key : `no_${key}`;
        }
        if (typeof value === 'number') {
          return `${key}_${this._discretize(value)}`;
        }
        return `${key}_${value}`;
      })
      .join(' ');
  }

  _discretize(value) {
    // Simple discretization for numerical values
    if (value === 0) return 'zero';
    if (value <= 5) return 'very_low';
    if (value <= 10) return 'low';
    if (value <= 20) return 'medium';
    if (value <= 50) return 'high';
    return 'very_high';
  }
}

module.exports = { PhishingDetector };