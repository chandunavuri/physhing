const { PhishingDetector } = require('./model');
const assert = require('assert');

// Test cases
function runTests() {
  console.log('Running tests...\n');

  const detector = new PhishingDetector();
  
  // Training data
  const trainingData = [
    { url: 'https://legitimate-bank.com/login', isPhishing: false },
    { url: 'http://suspicious-bank.fake.com/verify', isPhishing: true }
  ];

  // Train the model
  detector.train(trainingData);

  // Test 1: Legitimate URL
  console.log('Test 1: Legitimate URL detection');
  const legitResult = detector.predict('https://real-bank.com/account');
  assert(!legitResult.isPhishing, 'Should detect legitimate URL');
  console.log('✓ Passed\n');

  // Test 2: Phishing URL
  console.log('Test 2: Phishing URL detection');
  const phishingResult = detector.predict('http://bank-security-verify.suspicious.net/login');
  assert(phishingResult.isPhishing, 'Should detect phishing URL');
  console.log('✓ Passed\n');

  console.log('All tests passed successfully!');
}

runTests();