const { PhishingDetector } = require('./model');

// Sample training data
const trainingData = [
  { 
    url: 'https://legitimate-bank.com/login',
    isPhishing: false
  },
  {
    url: 'https://legit-shop.com/products',
    isPhishing: false
  },
  {
    url: 'http://bank-secure-login.suspicious.com/login',
    isPhishing: true
  },
  {
    url: 'https://banking.secure.suspicious.net/verify',
    isPhishing: true
  }
];

// Initialize and train the model
const detector = new PhishingDetector();
detector.train(trainingData);

// Example usage
const urlsToTest = [
  'https://mybank.com/login',
  'http://suspicious-login.fake-bank.net/verify',
  'https://legitimate-store.com/products',
  'http://amaz0n-security-verify.com/login'
];

console.log('Phishing Detection Results:\n');

urlsToTest.forEach(url => {
  const result = detector.predict(url);
  console.log(`URL: ${url}`);
  console.log(`Result: ${result.isPhishing ? 'PHISHING' : 'LEGITIMATE'}`);
  console.log(`Confidence: ${(result.confidence * 100).toFixed(2)}%\n`);
});