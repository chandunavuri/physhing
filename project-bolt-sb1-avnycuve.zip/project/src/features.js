const URL = require('url-parse');
const tldExtract = require('tld-extract');

function extractFeatures(url) {
  const parsedUrl = new URL(url);
  const { domain, subdomain } = tldExtract(url);
  
  const features = {
    // Length-based features
    urlLength: url.length,
    domainLength: domain.length,
    
    // Domain-based features
    hasSubdomain: !!subdomain,
    numDots: (url.match(/\./g) || []).length,
    
    // Special character features
    numSpecialChars: (url.match(/[^a-zA-Z0-9]/g) || []).length,
    hasHyphen: url.includes('-'),
    
    // Protocol features
    isHttps: parsedUrl.protocol === 'https:',
    
    // Path features
    pathLength: parsedUrl.pathname.length,
    numPathSegments: parsedUrl.pathname.split('/').length - 1,
    
    // Query parameters
    hasQueryParams: !!parsedUrl.query,
    numQueryParams: (parsedUrl.query.match(/&/g) || []).length + 1
  };
  
  return features;
}

module.exports = { extractFeatures };